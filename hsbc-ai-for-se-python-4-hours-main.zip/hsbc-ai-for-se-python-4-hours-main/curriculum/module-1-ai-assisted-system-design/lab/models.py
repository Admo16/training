from enum import Enum

from pydantic import AwareDatetime, BaseModel, Field, field_validator


class PaymentState(str, Enum):
    submitted = "submitted"
    settled = "settled"
    failed = "failed"


class PaymentEvent(BaseModel):
    event_id: str = Field(min_length=1, max_length=64)
    payment_id: str = Field(min_length=1, max_length=64)
    state: PaymentState
    occurred_at: AwareDatetime

    @field_validator("event_id", "payment_id")
    @classmethod
    def validate_ids(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("ID must not be blank")
        return value


class PaymentStatus(BaseModel):
    payment_id: str = Field(min_length=1, max_length=64)
    state: PaymentState
    updated_at: AwareDatetime

    @field_validator("payment_id")
    @classmethod
    def validate_payment_id(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("Payment ID must not be blank")
        return value


class ErrorResponse(BaseModel):
    code: str | None = Field(default=None, min_length=1)
    message: str | None = Field(default=None, min_length=1)

    @field_validator("code", "message")
    @classmethod
    def validate_error_text(cls, value: str | None) -> str | None:
        if value is not None and not value.strip():
            raise ValueError("Error text must not be blank")
        return value
