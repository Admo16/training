# My assumptions for the Payment Status Service PRD

Pick the THREE gaps you think matter most. For each one, write the question and the default you will build on.
Keep each cell to one short line.

| # | Requirement (FR number or section) | Question for the product owner | My default until they answer |
|---|---|---|---|
| 1 | FR1/FR5 | What unique notification or payment event ID will the rail provide, and will duplicate deliveries reuse it? | Use a globally unique notification_id as the database primary key and return success for duplicate deliveries. |
| 2 | FR3/FR6 | Which authenticated roles may query each payment, and can callers search by fields other than payment_id? | Allow role-based access to GET /payments/{payment_id} and return 404 for unknown IDs. |
| 3 | FR1/FR3/FR2 | What latency, availability, throughput, recovery, retention, retry, authentication, and audit requirements apply? | Use authenticated HTTPS, a relational database with backups and health checks, bounded retries, and p95 lookup latency below 250 ms. Treat these as placeholders until measurable targets are approved. |

Riskiest of the three (one line, and why):
#2 is the riskiest. Need to make sure that  only autheticated and authorized users are able to access the payment.