"""Service configuration."""
import os


def db_password(environ=os.environ) -> str:
    value = environ.get("DB_PASSWORD")
    if not value:
        raise RuntimeError("DB_PASSWORD is required")
    return value


def pricing_api_key(environ=os.environ) -> str:
    value = environ.get("PRICING_API_KEY")
    if not value:
        raise RuntimeError("PRICING_API_KEY is required")
    return value
