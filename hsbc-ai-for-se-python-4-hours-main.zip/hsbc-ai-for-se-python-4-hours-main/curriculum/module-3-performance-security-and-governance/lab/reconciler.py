"""End-of-day reconciliation helpers.

They work, but they are slow and verbose. THIS is the file you refactor with your AI assistant.
The rule: behaviour must not change. The tests in tests/ are your safety net.
"""
from collections import Counter
from decimal import Decimal

from transactions import Transaction


def find_duplicate_ids(transactions: list[Transaction]) -> list[str]:
    """Ids that appear more than once, each listed once, in the order their FIRST occurrence appears."""
    counts = Counter(transaction.txn_id for transaction in transactions)
    return [txn_id for txn_id, count in counts.items() if count > 1]


def total_by_currency(transactions: list[Transaction]) -> dict[str, Decimal]:
    """Total amount per currency."""
    totals = {}
    for transaction in transactions:
        if transaction.currency in totals:
            totals[transaction.currency] = totals[transaction.currency] + transaction.amount
        else:
            totals[transaction.currency] = transaction.amount
    return totals


def count_by_status(transactions: list[Transaction]) -> dict[str, int]:
    """Number of transactions per status."""
    counts = Counter(transaction.status for transaction in transactions)
    return dict(counts)
